# Loan Default Prediction - Exploratory Data Analysis

## Introduction This notebook performs exploratory data analysis on the loan default prediction dataset. We'll analyze various features to understand their relationship with loan default status and identify important patterns that can help in building our prediction model.

## Data Loading and Initial Inspection
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Set style for visualizations
plt.style.use('seaborn-v0_8-white') # Use the updated style name with version prefix
sns.set_palette("husl")


# Load the data
train_data = pd.read_excel('train_data.xlsx')
test_data = pd.read_excel('test_data.xlsx')

# Display basic information about the datasets
print("Training Dataset Info:")
print(train_data.info())
print("\nTest Dataset Info:")
print(test_data.info())

# Basic statistics of numerical columns
print("\nNumerical Features Statistics:")
numerical_stats = train_data.describe()
print(numerical_stats)

# Check for missing values
print("\nMissing Values in Training Data:")
print(train_data.isnull().sum())

# Distribution of target variable
plt.figure(figsize=(10, 6))
sns.countplot(data=train_data, x='loan_status')
plt.title('Distribution of Loan Default Status')
plt.show()

# Analyze numerical features
numerical_features = ['cibil_score', 'total_no_of_acc', 'annual_inc', 
                     'int_rate', 'loan_amnt', 'installment', 'account_bal', 
                     'emp_length']

fig, axes = plt.subplots(4, 2, figsize=(15, 20))
axes = axes.ravel()

for idx, col in enumerate(numerical_features):
    sns.boxplot(data=train_data, y=col, x='loan_status', ax=axes[idx])
    axes[idx].set_title(f'Distribution of {col} by Loan Status')

plt.tight_layout()
plt.show()

# Analyze categorical features
categorical_features = ['sub_grade', 'home_ownership', 'purpose', 
                       'application_type', 'verification_status']

for feature in categorical_features:
    plt.figure(figsize=(12, 6))
    default_rates = train_data.groupby(feature)['loan_status'].mean().sort_values(ascending=False)
    default_rates.plot(kind='bar')
    plt.title(f'Default Rate by {feature}')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# Correlation analysis
correlation_matrix = train_data[numerical_features + ['loan_status']].corr()
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0)
plt.title('Correlation Matrix of Numerical Features')
plt.tight_layout()
plt.show()

# Time series analysis
train_data['transaction_date'] = pd.to_datetime(train_data['transaction_date'])
monthly_defaults = train_data.groupby(train_data['transaction_date'].dt.to_period('M'))['loan_status'].mean()

plt.figure(figsize=(15, 6))
monthly_defaults.plot(kind='line', marker='o')
plt.title('Monthly Default Rate Over Time')
plt.xlabel('Month')
plt.ylabel('Default Rate')
plt.grid(True)
plt.tight_layout()
plt.show()

# Key insights summary
print("\nKey Insights from EDA:")
print("1. Target Variable Distribution:")
print(train_data['loan_status'].value_counts(normalize=True))

print("\n2. Most Correlated Features with Loan Default:")
correlations = correlation_matrix['loan_status'].sort_values(ascending=False)
print(correlations)

print("\n3. Statistical Tests:")
# Perform t-test for numerical features
for feature in numerical_features:
    default_group = train_data[train_data['loan_status'] == 1][feature]
    non_default_group = train_data[train_data['loan_status'] == 0][feature]
    t_stat, p_value = stats.ttest_ind(default_group, non_default_group)
    print(f"\n{feature}:")
    print(f"t-statistic: {t_stat:.4f}")
    print(f"p-value: {p_value:.4f}")