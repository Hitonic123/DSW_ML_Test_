import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
import pickle

class LoanDefaultModel:
    """
    A class to handle loan default prediction modeling pipeline.
    Includes data loading, preprocessing, training, testing, and prediction functionality.
    """

    def __init__(self, model_algorithm):
        """
        Initialize the model with specified algorithm

        Parameters:
        -----------
        model_algorithm : sklearn estimator
            The machine learning algorithm to be used for training
        """
        self.model = model_algorithm
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_columns = None

    def load(self, filepath):
        """
        Load data from specified filepath

        Parameters:
        -----------
        filepath : str
            Path to the data file

        Returns:
        --------
        pandas.DataFrame
            Loaded dataset
        """
        return pd.read_excel(filepath)

    def preprocess(self, data, is_training=True):
        """
        Preprocess the data for modeling

        Parameters:
        -----------
        data : pandas.DataFrame
            Input data to preprocess
        is_training : bool
            Whether this is training data or not

        Returns:
        --------
        numpy.ndarray
            Preprocessed features
        """
        data = data.copy()  # Avoid SettingWithCopyWarning
        data['transaction_date'] = pd.to_datetime(data['transaction_date'])
        data['transaction_month'] = data['transaction_date'].dt.month
        data['transaction_year'] = data['transaction_date'].dt.year

        categorical_columns = ['sub_grade', 'home_ownership', 'purpose', 'application_type', 'verification_status']
        for col in categorical_columns:
            if is_training:
                self.label_encoders[col] = LabelEncoder()
                data[col] = self.label_encoders[col].fit_transform(data[col])
            else:
                if col in self.label_encoders:
                    known_labels = self.label_encoders[col].classes_
                    data[col] = data[col].apply(lambda x: self.label_encoders[col].transform([x])[0] if x in known_labels else -1)
                else:
                    raise ValueError(f"Unseen category in column '{col}' during preprocessing.")

        feature_cols = ['sub_grade', 'term', 'home_ownership', 'cibil_score',
                        'total_no_of_acc', 'annual_inc', 'int_rate', 'loan_amnt',
                        'installment', 'account_bal', 'emp_length',
                        'transaction_month', 'transaction_year']

        if is_training:
            self.feature_columns = feature_cols

        X = data[self.feature_columns].copy()

        if 'term' in X.columns:
            X['term'] = X['term'].str.replace(' months', '').astype(int)

        if is_training:
            X = self.scaler.fit_transform(X)
        else:
            X = self.scaler.transform(X)

        return X

    def train(self, X_train, y_train):
        """
        Train the model

        Parameters:
        -----------
        X_train : numpy.ndarray
            Training features
        y_train : numpy.ndarray
            Training labels
        """
        self.model.fit(X_train, y_train)

    def test(self, X_test, y_test):
        """
        Test the model and generate evaluation metrics

        Parameters:
        -----------
        X_test : numpy.ndarray
            Test features
        y_test : numpy.ndarray
            Test labels

        Returns:
        --------
        dict
            Dictionary containing evaluation metrics
        """
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)[:, 1]

        evaluation = {
            'classification_report': classification_report(y_test, y_pred),
            'confusion_matrix': confusion_matrix(y_test, y_pred),
            'roc_auc_score': roc_auc_score(y_test, y_pred_proba)
        }

        return evaluation

    def predict(self, X):
        """
        Make predictions on new data

        Parameters:
        -----------
        X : numpy.ndarray
            Features to predict on

        Returns:
        --------
        numpy.ndarray
            Predicted probabilities of default
        """
        return self.model.predict_proba(X)[:, 1]

    def save_model(self, filepath):
        """
        Save the trained model to disk

        Parameters:
        -----------
        filepath : str
            Path where to save the model
        """
        model_artifacts = {
            'model': self.model,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders,
            'feature_columns': self.feature_columns
        }
        with open(filepath, 'wb') as f:
            pickle.dump(model_artifacts, f)

    def load_model(self, filepath):
        """
        Load a trained model from disk

        Parameters:
        -----------
        filepath : str
            Path to the saved model
        """
        with open(filepath, 'rb') as f:
            model_artifacts = pickle.load(f)

        self.model = model_artifacts['model']
        self.scaler = model_artifacts['scaler']
        self.label_encoders = model_artifacts['label_encoders']
        self.feature_columns = model_artifacts['feature_columns']

# File paths
train_filepath = "train_data.xlsx"
test_filepath = "test_data.xlsx"

# Load and preprocess data
train_data = pd.read_excel(train_filepath)
y = train_data['loan_status']

model_classes = [
    ("Logistic Regression", LogisticRegression(max_iter=1000)),
    ("Decision Tree", DecisionTreeClassifier()),
    ("Random Forest", RandomForestClassifier()),
    ("Gradient Boosting", GradientBoostingClassifier())
]

for model_name, model_algorithm in model_classes:
    print(f"\n===== {model_name} =====")

    # Initialize model
    loan_model = LoanDefaultModel(model_algorithm)
    X = loan_model.preprocess(train_data)

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train the model
    loan_model.train(X_train, y_train)

    # Test the model
    evaluation = loan_model.test(X_test, y_test)

    # Display results
    print("Classification Report:")
    print(evaluation['classification_report'])
    print("Confusion Matrix:\n", evaluation['confusion_matrix'])
    print("ROC AUC Score:", evaluation['roc_auc_score'])

    # Predict on new data
    new_data = loan_model.preprocess(train_data.iloc[:5], is_training=False)
    predictions = loan_model.predict(new_data)
    print("Predicted probabilities for new data:", predictions)
